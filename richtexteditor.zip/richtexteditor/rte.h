
#define ccCRLF	chr(13)+chr(10)
#define ccCRLF2	ccCRLF + ccCRLF
#define ccCR 	chr(13)
#define ccTAB	chr(9)

